# HERO Assets

- Hero ID: 666
- Name: NAME
- Source: In-game portrait
- Notes:
  - Used across Arrest and War modes